/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.runapplication;

import java.util.Scanner;

/**
 *
 * @author Lesedi
 */
public class RunApplication {

    public static void main(String[] args) {
        
       Scanner input = new Scanner(System.in);
       
   String consoleType = "";
        String store;
        int totalSales;
        int choice;

        // Display the console menu
        System.out.println("Select the console type");
        System.out.println();
        System.out.println("1) PS5");
        System.out.println("2) XBOX");
        System.out.println("3) SWITCH");
        System.out.println();

        // Get the user's choice
        choice = input.nextInt();
        input.nextLine();

        // Determine the console type
        if (choice == 1) {
            consoleType = "PS5";
        } else if (choice == 2) {
            consoleType = "XBOX";
        } else if (choice == 3) {
            consoleType = "SWITCH";
        } else {
            System.out.println("Invalid choice");
            System.exit(0);
        }

        // Get the store name
        System.out.print("Enter the store: ");
        store = input.nextLine();

        // Get the total sales
        System.out.print("Enter the total sales of the "
                + consoleType + " console for the "
                + store + ": ");
        totalSales = input.nextInt();

        // Create ConsoleSales object
        ConsoleSales sales = new ConsoleSales(
                consoleType, store, totalSales);

        // Print the report
        sales.printReport();

        input.close();
    }
}